This folder is for weapons GUARDS ingame will use. Players may or may not use weapons with these textures.
