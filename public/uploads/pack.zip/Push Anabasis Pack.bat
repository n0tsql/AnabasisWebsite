
@echo off
setlocal

:: Anabasis resource pack paths
set "PACK_DIR=%~dp0"
set "ZIP_OUT=%~dp0packxport\pack.zip"
set "ZIP_TOOL=%ProgramFiles%\7-Zip\7z.exe"
set "ANABASIS_RCON_PASSWORD=ANABASIS$676767\!@\#$%^&*()-\=n3ww0rld0rder67$jimmyjonga-kyle-busch-darrel-cartrip-johio-joebama-trumpFortnite-ballsack"
if not exist "%ZIP_TOOL%" set "ZIP_TOOL=%ProgramFiles(x86)%\7-Zip\7z.exe"

if not exist "%ZIP_TOOL%" (
    echo ERROR: Cannot find 7-Zip.
    echo Check where 7z.exe is installed.
    pause
    exit /b 1
)
if not exist "%~dp0packxport" mkdir "%~dp0packxport"

"%ZIP_TOOL%" a -tzip "%ZIP_OUT%" "%PACK_DIR%*" ^
    -x!*.bat ^
    -x!packxport\* ^
    -y
set "UPLOAD_URL=https://anabasisrpg.com/upload.php"
set "MCRCON=C:\AnabasisTools\mcrcon.exe"

:: Set these for your development server
set "RCON_HOST=172.93.104.65"
set "RCON_PORT=8140"
set "RELOAD_COMMAND=nexo reload pack"

echo [Anabasis] Building resource pack...

if not exist "%ZIP_TOOL%" (
    echo ERROR: 7-Zip not found.
    exit /b 1
)

if not exist "%PACK_DIR%\" (
    echo ERROR: Resource pack folder not found.
    exit /b 1
)

if exist "%ZIP_OUT%" del "%ZIP_OUT%"

"%ZIP_TOOL%" a -tzip "%ZIP_OUT%" "%PACK_DIR%\*" -y >nul
if errorlevel 1 (
    echo ERROR: Failed to build ZIP.
    exit /b 1
)

if not exist "%ZIP_OUT%" (
    echo ERROR: ZIP was not created.
    exit /b 1
)

echo [Anabasis] Uploading pack...

curl.exe -fsS --fail-with-body ^
    -F "file=@%ZIP_OUT%" ^
    "%UPLOAD_URL%"

if errorlevel 1 (
    echo ERROR: Upload failed; reload skipped.
    exit /b 1
)

echo [Anabasis] Upload completed.

:: Trigger the server reload only after upload succeeds.
:: The command must be supported by the server console.
if exist "%MCRCON%" (
    "%MCRCON%" -H "%RCON_HOST%" -P "%RCON_PORT%" ^
        -p "%ANABASIS_RCON_PASSWORD%" "%RELOAD_COMMAND%"

    if errorlevel 1 (
        echo WARNING: RCON command failed.
        exit /b 1
    )
) else (
    echo WARNING: mcrcon.exe not found; reload skipped.
    exit /b 1
)

echo [Anabasis] Push and reload complete.
powershell -NoProfile -Command "(New-Object Media.SoundPlayer 'C:\Windows\Media\chimes.wav').PlaySync()"

endlocal